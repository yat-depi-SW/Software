﻿using DataAccess.Entities;

namespace DataAccess.Types
{
    public struct StaffWithRole
    {
        public Staff data;
        public string role;
    }
}
