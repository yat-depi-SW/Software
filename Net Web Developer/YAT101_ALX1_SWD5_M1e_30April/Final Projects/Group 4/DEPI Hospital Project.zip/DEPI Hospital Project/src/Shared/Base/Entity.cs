﻿namespace Shared.Base
{
    public class Entity
    {
        public uint Id { get; set; }
    }
}
