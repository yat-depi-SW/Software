﻿namespace Shared.Enums
{
    public enum AppointmentStatus : byte
    {
        Pending,
        Canceled,
        Completed
    }
}
