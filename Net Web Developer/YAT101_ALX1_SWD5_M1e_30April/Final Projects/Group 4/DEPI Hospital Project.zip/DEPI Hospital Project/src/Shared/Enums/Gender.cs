﻿namespace Shared.Enums
{
    public enum Gender : byte
    {
        Male,
        Female
    }
}
