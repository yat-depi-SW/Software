﻿namespace Shared.Enums
{
    public enum AppointmentType : byte
    {
        Diagnoses,
        FollowUp,
        UrgentCare,
        HealthQuery
    }
}
