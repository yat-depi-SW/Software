﻿namespace Shared.Enums
{
    public enum Shift : byte
    {

    }
}
