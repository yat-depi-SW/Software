﻿namespace LearnIn.Models
{
    public enum ContentType
    {
        Video,
        File
    }
}
