﻿namespace Services_Booking_System.View_Models
{
    public class TechniciansViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string JobTitle { get; set; }
        public string Email { get; set; }
        public decimal Rating { get; set; }

    }
}
