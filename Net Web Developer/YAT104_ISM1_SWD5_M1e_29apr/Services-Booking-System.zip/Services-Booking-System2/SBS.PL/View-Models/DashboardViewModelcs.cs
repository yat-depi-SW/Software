﻿namespace Services_Booking_System.View_Models
{
    public class DashboardViewModel
    {
        public int UserCount { get; set; }
        public int TechnicianCount { get; set; }
        public int AdminsCount { get; set; }
        public int CategoriesCount { get; set; }
        public int ServicesCount { get; set; }
        public int NumberOfBookings { get; set; }
    }
}
