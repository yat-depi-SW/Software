﻿//namespace WEBPage.View_Models
//{
//    public class ServiceListViewModel
//    {
//        public class ServiceListViewModel
//        {
//            public IEnumerable<Category> Categories { get; set; }
//            public IEnumerable<Service> Services { get; set; }
//            public int? SelectedCategoryId { get; set; }
//        }
//    }
//}
