﻿using Microsoft.AspNetCore.Identity;

namespace WEBPage.Models.Identity
{
    public class ApplicationRole:IdentityRole
    {
    }
}
