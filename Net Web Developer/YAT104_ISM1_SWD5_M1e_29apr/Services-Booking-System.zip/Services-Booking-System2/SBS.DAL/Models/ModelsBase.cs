﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingService.DAL.Models;

public class ModelsBase
{
	public int Id { get; set; }
}
