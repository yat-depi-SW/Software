﻿namespace BookingService.BLL.Interfaces
{
    public interface IQuerble<T>
    {
    }
}