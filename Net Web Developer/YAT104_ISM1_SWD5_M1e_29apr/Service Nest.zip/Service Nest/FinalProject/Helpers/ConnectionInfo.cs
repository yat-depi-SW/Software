﻿namespace FinalProject.Helpers
{
    public class UserConnectionInfo
    {
        public string ConnectionId { get; set; }
        public string UserName { get; set; }
    }
}
