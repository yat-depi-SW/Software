﻿namespace FinalProject.Services
{
    public interface IUserService
    {
        string GetUserAddressById(string userId);
    }
}
