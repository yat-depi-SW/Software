# devops-aws
This project requires you to create a comprehensive DevOps pipeline utilizing AWS infrastructure, Kubernetes (k3s), Docker, Ansible, Jenkins, Git, Terraform, and Helm. The goal is to deploy a sample Node.js application into a Kubernetes cluster, with CI/CD pipeline automation orchestrated by Jenkins.
