#!/bin/bash
export ANSIBLE_PRIVATE_KEY_FILE="/home/ubuntu/.ssh/my-key"
export ANSIBLE_HOST_KEY_CHECKING=False
