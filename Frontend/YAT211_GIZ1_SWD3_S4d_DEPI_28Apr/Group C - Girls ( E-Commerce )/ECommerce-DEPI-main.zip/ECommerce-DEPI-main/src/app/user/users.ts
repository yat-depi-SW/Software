export const Users = [
  {
    id: 'u1',
    name: 'Ahmed',
    img: 'assets/images/img4.png',
  },
  {
    id: 'u2',
    name: 'aly',
    img: 'assets/images/word icon.jpg',
  },
  {
    id: 'u3',
    name: 'amr',
    img: 'assets/images/word.jpg',
  },
];
