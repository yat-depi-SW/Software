class onBoardngModel {
  final String? title;
  final String? image;
  final String? body;
  onBoardngModel({this.body, this.title, this.image});
}
