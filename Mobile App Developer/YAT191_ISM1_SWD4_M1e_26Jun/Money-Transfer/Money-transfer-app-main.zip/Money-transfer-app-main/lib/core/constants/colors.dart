import 'package:flutter/material.dart';

const TextColor1 = Color(0xff2f1155);
const TextColor2 =Color(0xFF3177FF);
const buttonColor1 = Color(0xff5063bf);
const kColor1 = Color(0xff5063bf);
const schafoldGrey = Color.fromRGBO(224, 224, 224, 1);
