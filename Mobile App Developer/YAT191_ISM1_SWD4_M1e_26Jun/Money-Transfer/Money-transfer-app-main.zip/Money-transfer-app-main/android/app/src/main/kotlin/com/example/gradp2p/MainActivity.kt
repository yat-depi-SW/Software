package com.example.gradp2p

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
